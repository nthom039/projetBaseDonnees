<?php
    /*$conn = pg_connect("host=localhost port=5433 user=postgres password=admin123 dbname=postgres");
    if (!$conn){ die("PostgreSQL connection failed"); }
    echo "PostgreSQL  connected successfully<br/>";*/

    $hotelID = null;

    function findHotel($searchArray, $conn){
        $queryString = '';
        for($i = 0; $i < count($searchArray); $i++){
            if($i == 0){ $queryString = "WHERE ". $searchArray[$i]; }
            else{ $queryString = $queryString. " and ". $searchArray[$i]; }
        }

        return pg_query($conn, "SELECT * from hotel ". $queryString);
    }

    function hotelSelected($id){
        $hotelID = $id;
        header("Location: /roomFinder.php");
        exit();
    }
?>