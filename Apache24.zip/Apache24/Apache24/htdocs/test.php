<!DOCTYPE html>
<html>
<head>
    <style>
        table{
            width: 70%;
            margin: auto;
            font-family: Arial, Helvetica, sans-serif;
        }
        table, tr, th, td{
            border: 1px solid #d4d4d4;
            border-collapse: collapse;
            padding: 12px;
        }
        th, td{
            text-align: left;
            vertical-align: top;
        }
        tr:nth-child(even){
            background-color: #e7e9eb;
        }
    </style>
</head>
<body>
    <form id="testform" name="testform" method="post" action="">
        <p>
            Search Hotel:<br/>
            <label>Hotel chain:</label>
            <input name="chain" type="text" id="chain"/><br/>
            <label>City:</label>
            <input name="city" type="text" id="city"/><br/>
            <label>Country:</label>
            <input name="country" type="text" id="country"/><br/>
        </p>
        <br/>
        <p>
            <input type="submit" name="bgreet" value="Search" id="bgreet"/>
        </p>
        <br/>
        <br/>
    </form>

    <?php
        $conn = pg_connect("host=localhost port=5433 user=postgres password=ChuckNorris30#) dbname=postgres");
        if (!$conn){
            die("PostgreSQL connection failed");
        }
        echo "PostgreSQL  connected successfully<br/>";
        require __DIR__ . '\queryFunctions.php';

        $searchArray = array();
        $queryString = "";
        $result = null;

        if(isset($_POST['bgreet'])){
            echo 'HERE _______________________ HERE';
        }

        if(isset($_POST['bgreet'])){
            if($_POST['chain'] != null){
                $chain      = "nom_chaine = '". $_POST['chain']. "'";
                array_push($searchArray, $chain);
            }

            if($_POST['city'] != null){
                $city       = "adresse LIKE '%". $_POST['city']. "%'";
                array_push($searchArray, $city);
            }

            if($_POST['country'] != null){
                $country       = "adresse LIKE '%". $_POST['country']. "%'";
                array_push($searchArray, $country);
            }

            $result = findHotel($searchArray, $conn);

            echo '<table> <tr> <th> Chain Name </th> <th> # </th> <th> Adresse </th> <th> Nombre de chambre </th> </tr>';
            while($row = pg_fetch_row($result)){
                echo '<tr > <td>' . $row[4] . '</td>
            <td>' . $row[3] . '</td>
            <td> ' . $row[2] . '</td>
            <td>' . $row[1] . '</td>
            <td> <form method="get"><input type="submit" name="pickHotel" value="Select" id="'. $row[0]. '"/></form> </td> </tr>';
            }
            echo '</table>';
        }

        if(isset($_GET['pickHotel'])){
            echo $_GET['pickHotel'];
            //hotelSelected($_POST['pickHotel']);
        }

        pg_close($conn);
    ?>

</body>
</html>